/* @ds-bundle: {"format":3,"namespace":"RoboAcademy4KidsDesignSystem_51382b","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Tag","sourcePath":"components/core/Tag.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"80aadf3bb6bd","components/core/Badge.jsx":"545b045b7c62","components/core/Button.jsx":"0795c07d32a3","components/core/Card.jsx":"b63b39bd2115","components/core/Tag.jsx":"6275d8db15f3","ui_kits/website/LandingPage.jsx":"57345017ad37"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.RoboAcademy4KidsDesignSystem_51382b = window.RoboAcademy4KidsDesignSystem_51382b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Round avatar with a colored ring. Shows initials, or the robot mascot fallback. */
function Avatar({
  name = '',
  src = null,
  size = 48,
  ring = 'var(--ra-cyan)',
  style = {},
  ...rest
}) {
  const initials = name ? name.trim().split(/\s+/).slice(0, 2).map(w => w[0].toUpperCase()).join('') : '';
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      justifyContent: 'center',
      width: size,
      height: size,
      borderRadius: '50%',
      background: 'var(--ra-navy-700)',
      color: '#fff',
      fontFamily: 'var(--font-display)',
      fontWeight: 600,
      fontSize: size * 0.4,
      border: `3px solid ${ring}`,
      overflow: 'hidden',
      flex: '0 0 auto',
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: '100%',
      height: '100%',
      objectFit: 'cover'
    }
  }) : initials || '🤖');
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Small status / category pill in mono uppercase. */
function Badge({
  tone = 'cyan',
  children,
  style = {},
  ...rest
}) {
  const tones = {
    cyan: {
      bg: 'var(--ra-cyan)',
      fg: 'var(--ra-navy-900)'
    },
    violet: {
      bg: 'var(--ra-violet)',
      fg: '#fff'
    },
    lime: {
      bg: 'var(--ra-lime)',
      fg: 'var(--ra-navy-900)'
    },
    yellow: {
      bg: 'var(--ra-yellow)',
      fg: 'var(--ra-navy-900)'
    },
    coral: {
      bg: 'var(--ra-coral)',
      fg: '#fff'
    },
    neutral: {
      bg: 'var(--ra-navy-700)',
      fg: 'var(--text-on-dark)'
    }
  };
  const t = tones[tone] || tones.cyan;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 6,
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 12,
      letterSpacing: '0.1em',
      textTransform: 'uppercase',
      padding: '3px 10px',
      borderRadius: 'var(--radius-pill)',
      background: t.bg,
      color: t.fg,
      lineHeight: 1.4,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * RoboAcademy4Kids primary action control.
 * Chunky, rounded, with a tactile "press down" offset shadow.
 */
function Button({
  variant = 'primary',
  size = 'md',
  disabled = false,
  fullWidth = false,
  iconLeft = null,
  iconRight = null,
  children,
  style = {},
  ...rest
}) {
  const sizes = {
    sm: {
      padding: '8px 14px',
      fontSize: 14,
      minHeight: 36,
      gap: 6
    },
    md: {
      padding: '12px 20px',
      fontSize: 16,
      minHeight: 44,
      gap: 8
    },
    lg: {
      padding: '16px 28px',
      fontSize: 18,
      minHeight: 52,
      gap: 10
    }
  };
  const variants = {
    primary: {
      background: 'var(--ra-cyan)',
      color: 'var(--ra-navy-900)',
      border: '2px solid var(--ra-navy-900)',
      boxShadow: '0 4px 0 var(--ra-cyan-600)'
    },
    secondary: {
      background: 'var(--ra-violet)',
      color: '#fff',
      border: '2px solid var(--ra-navy-900)',
      boxShadow: '0 4px 0 var(--ra-violet-600)'
    },
    accent: {
      background: 'var(--ra-yellow)',
      color: 'var(--ra-navy-900)',
      border: '2px solid var(--ra-navy-900)',
      boxShadow: '0 4px 0 var(--ra-yellow-600)'
    },
    ghost: {
      background: 'transparent',
      color: 'var(--text-on-dark)',
      border: '2px solid var(--color-border-strong)',
      boxShadow: 'none'
    }
  };
  const s = sizes[size] || sizes.md;
  const v = variants[variant] || variants.primary;
  const base = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: s.gap,
    fontFamily: 'var(--font-display)',
    fontWeight: 600,
    fontSize: s.fontSize,
    lineHeight: 1,
    padding: s.padding,
    minHeight: s.minHeight,
    width: fullWidth ? '100%' : 'auto',
    borderRadius: 'var(--radius-pill)',
    cursor: disabled ? 'not-allowed' : 'pointer',
    opacity: disabled ? 0.5 : 1,
    transition: 'transform var(--dur-fast) var(--ease-out), box-shadow var(--dur-fast) var(--ease-out)',
    userSelect: 'none',
    WebkitTapHighlightColor: 'transparent',
    ...v,
    ...style
  };
  const press = (e, down) => {
    if (disabled || v.boxShadow === 'none') return;
    e.currentTarget.style.transform = down ? 'translateY(3px)' : 'translateY(0)';
    e.currentTarget.style.boxShadow = down ? v.boxShadow.replace('4px', '1px') : v.boxShadow;
  };
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    style: base,
    onMouseDown: e => press(e, true),
    onMouseUp: e => press(e, false),
    onMouseLeave: e => press(e, false)
  }, rest), iconLeft, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * Chunky rounded container. Light by default; pass tone="dark" for dark surfaces.
 * Optional accent color paints a thick top edge.
 */
function Card({
  tone = 'light',
  accent = null,
  padding = 'var(--space-5)',
  children,
  style = {},
  ...rest
}) {
  const dark = tone === 'dark';
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: dark ? 'var(--ra-navy-800)' : 'var(--ra-white)',
      color: dark ? 'var(--text-on-dark)' : 'var(--text-on-light)',
      border: `2px solid ${dark ? 'var(--color-border)' : 'var(--border-card)'}`,
      borderTop: accent ? `6px solid ${accent}` : undefined,
      borderRadius: 'var(--radius-lg)',
      boxShadow: dark ? 'none' : 'var(--shadow-md)',
      padding,
      ...style
    }
  }, rest), children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Tag.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Selectable category chip with a leading color dot. */
function Tag({
  color = 'var(--ra-cyan)',
  selected = false,
  children,
  style = {},
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: 'inline-flex',
      alignItems: 'center',
      gap: 8,
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      fontSize: 14,
      padding: '7px 14px',
      borderRadius: 'var(--radius-pill)',
      background: selected ? color : 'transparent',
      color: selected ? 'var(--ra-navy-900)' : 'var(--text-on-dark)',
      border: `2px solid ${selected ? color : 'var(--color-border-strong)'}`,
      cursor: 'pointer',
      userSelect: 'none',
      lineHeight: 1,
      transition: 'all var(--dur-fast) var(--ease-out)',
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      width: 9,
      height: 9,
      borderRadius: '50%',
      background: selected ? 'var(--ra-navy-900)' : color,
      flex: '0 0 auto'
    }
  }), children);
}
Object.assign(__ds_scope, { Tag });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Tag.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/LandingPage.jsx
try { (() => {
// RoboAcademy4Kids — marketing landing page (UI kit screen).
// Composes Button, Badge, Card, Tag, Avatar from the design-system bundle.
const {
  Button,
  Badge,
  Card,
  Tag,
  Avatar
} = window.RoboAcademy4KidsDesignSystem_51382b;
const MASCOT = '../../assets/mascot-bolt.svg';
const COURSES = [{
  id: 'rb',
  title: 'Intro to Robotics',
  accent: 'var(--ra-cyan)',
  level: 'Beginner',
  weeks: 6,
  blurb: 'Build and program your first rolling, sensing robot.',
  topics: ['Robotics', 'Sensors']
}, {
  id: 'cq',
  title: 'Code Quest',
  accent: 'var(--ra-violet)',
  level: 'Beginner',
  weeks: 8,
  blurb: 'Block-based coding adventures, mini-games and puzzles.',
  topics: ['Coding', 'Game Design']
}, {
  id: 'el',
  title: 'Spark Lab: Electronics',
  accent: 'var(--ra-lime)',
  level: 'Intermediate',
  weeks: 6,
  blurb: 'Wire up circuits, lights and buzzers that really work.',
  topics: ['Electronics', 'Robotics']
}];
function Logo({
  light
}) {
  return /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: MASCOT,
    alt: "",
    style: {
      height: 42
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 3,
      lineHeight: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 22,
      letterSpacing: '-0.01em'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ra-cyan)'
    }
  }, "Robo"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: light ? 'var(--ra-ink)' : '#fff'
    }
  }, "Academy")), /*#__PURE__*/React.createElement("span", {
    style: {
      alignSelf: 'flex-start',
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      fontSize: 9,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      background: 'var(--ra-yellow)',
      color: 'var(--ra-navy-900)',
      borderRadius: 999,
      padding: '1px 7px'
    }
  }, "4 Kids")));
}
function Nav({
  onEnroll
}) {
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '18px 32px',
      position: 'sticky',
      top: 0,
      background: 'rgba(10,14,31,0.85)',
      backdropFilter: 'blur(10px)',
      borderBottom: '1px solid var(--color-border)',
      zIndex: 10
    }
  }, /*#__PURE__*/React.createElement(Logo, null), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 22
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#courses",
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      color: 'var(--text-on-dark)',
      textDecoration: 'none',
      fontSize: 15
    }
  }, "Classes"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      color: 'var(--text-on-dark)',
      textDecoration: 'none',
      fontSize: 15
    }
  }, "Camps"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: {
      fontFamily: 'var(--font-body)',
      fontWeight: 700,
      color: 'var(--text-on-dark)',
      textDecoration: 'none',
      fontSize: 15
    }
  }, "About"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "sm",
    onClick: onEnroll
  }, "Enroll now")));
}
function Hero({
  onEnroll
}) {
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: 'relative',
      overflow: 'hidden',
      padding: '72px 32px 84px',
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      width: 320,
      height: 320,
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(34,211,238,.22), transparent 70%)',
      top: -80,
      left: -60
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      width: 360,
      height: 360,
      borderRadius: '50%',
      background: 'radial-gradient(circle, rgba(168,85,247,.20), transparent 70%)',
      bottom: -120,
      right: -80
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'relative',
      maxWidth: 720,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: MASCOT,
    alt: "",
    style: {
      height: 110,
      marginBottom: 20,
      filter: 'drop-shadow(0 0 22px rgba(34,211,238,.5))'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'center',
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "lime"
  }, "Summer enrollment open")), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 56,
      lineHeight: 1.04,
      letterSpacing: '-0.015em',
      margin: '0 0 18px',
      color: '#fff'
    }
  }, "Where kids ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ra-cyan)'
    }
  }, "build"), ",", /*#__PURE__*/React.createElement("br", null), "code & ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--ra-yellow)'
    }
  }, "play"), "."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 19,
      lineHeight: 1.5,
      color: 'var(--text-on-dark-muted)',
      maxWidth: 540,
      margin: '0 auto 30px'
    }
  }, "Hands-on robotics & coding classes for ages 8\u201312. Small groups, real robots, and a whole lot of high-fives."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 14,
      justifyContent: 'center',
      flexWrap: 'wrap'
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    size: "lg",
    onClick: onEnroll
  }, "Enroll now"), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    size: "lg"
  }, "Book a free tour"))));
}
function Courses({
  onEnroll
}) {
  return /*#__PURE__*/React.createElement("section", {
    id: "courses",
    style: {
      background: 'var(--ra-paper)',
      padding: '64px 32px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1040,
      margin: '0 auto'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      marginBottom: 38
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      letterSpacing: '0.18em',
      textTransform: 'uppercase',
      color: 'var(--ra-violet)',
      marginBottom: 8
    }
  }, "// Pick your track"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 38,
      color: 'var(--ra-ink)',
      margin: 0
    }
  }, "This term's classes")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(auto-fit,minmax(280px,1fr))',
      gap: 22
    }
  }, COURSES.map(c => /*#__PURE__*/React.createElement(Card, {
    key: c.id,
    accent: c.accent
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    tone: "yellow"
  }, "Ages 8\u201312"), /*#__PURE__*/React.createElement(Badge, {
    tone: "neutral"
  }, c.weeks, " weeks")), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 23,
      color: 'var(--ra-ink)',
      margin: '0 0 8px'
    }
  }, c.title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      fontSize: 15,
      lineHeight: 1.5,
      color: 'var(--text-on-light-muted)',
      margin: '0 0 16px'
    }
  }, c.blurb), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      flexWrap: 'wrap',
      marginBottom: 18
    }
  }, c.topics.map(t => /*#__PURE__*/React.createElement(Tag, {
    key: t,
    color: c.accent
  }, t))), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => onEnroll(c)
  }, "Enroll in ", c.title.split(':')[0]))))));
}
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      background: 'var(--ra-navy-900)',
      borderTop: '1px solid var(--color-border)',
      padding: '40px 32px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      flexWrap: 'wrap',
      gap: 18
    }
  }, /*#__PURE__*/React.createElement(Logo, null), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      color: 'var(--text-on-dark-muted)',
      letterSpacing: '0.06em'
    }
  }, "123 Maker Lane \xB7 Build \xB7 Code \xB7 Play \xB7 \xA9 2026"));
}
function EnrollModal({
  course,
  onClose
}) {
  const [done, setDone] = React.useState(false);
  if (!course) return null;
  return /*#__PURE__*/React.createElement("div", {
    onClick: onClose,
    style: {
      position: 'fixed',
      inset: 0,
      background: 'rgba(10,14,31,0.7)',
      backdropFilter: 'blur(4px)',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center',
      zIndex: 50,
      padding: 20
    }
  }, /*#__PURE__*/React.createElement("div", {
    onClick: e => e.stopPropagation(),
    style: {
      width: 'min(460px,100%)'
    }
  }, /*#__PURE__*/React.createElement(Card, {
    padding: "28px"
  }, !done ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 12,
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: MASCOT,
    alt: "",
    style: {
      height: 48
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 11,
      letterSpacing: '0.14em',
      textTransform: 'uppercase',
      color: 'var(--text-on-light-muted)'
    }
  }, "Enrollment"), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 22,
      margin: 0,
      color: 'var(--ra-ink)'
    }
  }, course.title))), /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Child's first name"), /*#__PURE__*/React.createElement("input", {
    style: inp,
    placeholder: "e.g. Maya"
  }), /*#__PURE__*/React.createElement("label", {
    style: lbl
  }, "Parent email"), /*#__PURE__*/React.createElement("input", {
    style: inp,
    placeholder: "you@email.com"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 10,
      marginTop: 22
    }
  }, /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    onClick: onClose,
    style: {
      color: 'var(--ra-ink)',
      borderColor: 'var(--ra-cloud)'
    }
  }, "Cancel"), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    fullWidth: true,
    onClick: () => setDone(true)
  }, "Reserve a spot"))) : /*#__PURE__*/React.createElement("div", {
    style: {
      textAlign: 'center',
      padding: '12px 0'
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: MASCOT,
    alt: "",
    style: {
      height: 72,
      marginBottom: 12
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: 'var(--font-display)',
      fontWeight: 700,
      fontSize: 24,
      color: 'var(--ra-ink)',
      margin: '0 0 8px'
    }
  }, "You're on the list! \uD83C\uDF89"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: 'var(--font-body)',
      color: 'var(--text-on-light-muted)',
      margin: '0 0 20px'
    }
  }, "We emailed next steps for ", /*#__PURE__*/React.createElement("strong", null, course.title), "."), /*#__PURE__*/React.createElement(Button, {
    variant: "primary",
    onClick: onClose
  }, "Done")))));
}
const lbl = {
  display: 'block',
  fontFamily: 'var(--font-body)',
  fontWeight: 700,
  fontSize: 13,
  color: 'var(--ra-ink)',
  margin: '12px 0 6px'
};
const inp = {
  width: '100%',
  boxSizing: 'border-box',
  fontFamily: 'var(--font-body)',
  fontSize: 15,
  padding: '11px 14px',
  borderRadius: 'var(--radius-md)',
  border: '2px solid var(--ra-cloud)',
  outline: 'none'
};
function LandingPage() {
  const [enroll, setEnroll] = React.useState(null);
  const open = c => setEnroll(c || COURSES[0]);
  return /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--ra-navy-900)',
      minHeight: '100vh'
    }
  }, /*#__PURE__*/React.createElement(Nav, {
    onEnroll: () => open()
  }), /*#__PURE__*/React.createElement(Hero, {
    onEnroll: () => open()
  }), /*#__PURE__*/React.createElement(Courses, {
    onEnroll: open
  }), /*#__PURE__*/React.createElement(Footer, null), /*#__PURE__*/React.createElement(EnrollModal, {
    course: enroll,
    onClose: () => setEnroll(null)
  }));
}
window.LandingPage = LandingPage;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/LandingPage.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Tag = __ds_scope.Tag;

})();
