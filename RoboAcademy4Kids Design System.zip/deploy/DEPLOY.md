# Deploy RoboAcademy4Kids to GitHub Pages

This folder is a complete static site — no build step. Everything here is plain files a browser can serve.

```
deploy/
├─ index.html          ← the site (page markup is inlined)
├─ ds-bundle.js        ← compiled design-system components
├─ styles.css          ← design tokens entry point
├─ tokens/             ← color/type/spacing/etc CSS
├─ assets/             ← Bolt the mascot (favicon + hero)
└─ .nojekyll           ← stops GitHub from hiding files (keep it!)
```

## Easiest path — upload in the browser (no git, no terminal)

1. Go to **github.com → New repository**. Name it e.g. `roboacademy4kids-site`, set **Public**, click **Create repository**.
2. On the new repo page, click **"uploading an existing file"**.
3. **Drag the *contents* of this `deploy/` folder** (the files, not the folder itself) into the upload box. Make sure `.nojekyll` is included.
4. Click **Commit changes**.
5. Go to **Settings → Pages**. Under **Build and deployment → Source**, pick **Deploy from a branch**, choose branch **main** and folder **/ (root)**, then **Save**.
6. Wait ~1 minute. Your site is live at:
   `https://<your-username>.github.io/<repo-name>/`

## Notes
- Fonts (Fredoka/Nunito/Space Mono) and React load from public CDNs, so the site needs an internet connection — normal for GitHub Pages.
- To use a custom domain later, add it under Settings → Pages → Custom domain.
- Want it at the root of `<username>.github.io` instead of a subpath? Name the repo exactly `<your-username>.github.io`.
